<?php

return [
    'displayName'  => 'Default',
    'type' => 'top',
    'theme_layout' => 'Default',
    'template_layout' => 'default',
    'preview'      => 'thumb.png',
	'order' => 1,
    "variables" => [
        'bodyClass' =>  'lagom-layout-top',
        'type'      =>  'default',
    ]
];