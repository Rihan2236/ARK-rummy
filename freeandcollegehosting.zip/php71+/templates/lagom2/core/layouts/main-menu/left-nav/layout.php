<?php

return [
    'display_name' => 'Left',
    'type' => 'left',
    'theme_layout' => 'Left',
    'template_layout' => 'left-nav',
    'preview'      => 'thumb.png',
	'order' => 4,
    "variables" => [
        'bodyClass' =>  'lagom-layout-left',
        'type'      =>  'navbar-left',
    ]
];