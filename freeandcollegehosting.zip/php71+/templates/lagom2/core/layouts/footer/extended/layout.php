<?php

return [
    'display_name' => 'Extended',
    'version'      => '1.0.0',
    'preview'      => 'thumb.png',
	'order' => 2,
    "variables" => [
        'footerClass' =>  '',
        'type'      =>  'extended',
    ]
];