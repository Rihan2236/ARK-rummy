<?php
header("Location: ../index.php");