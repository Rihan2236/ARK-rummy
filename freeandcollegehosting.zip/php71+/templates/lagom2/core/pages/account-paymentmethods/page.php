<?php

return [
    'display_name' => 'Account Payment Methods',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => true,
    'variables'    => [

    ],
];