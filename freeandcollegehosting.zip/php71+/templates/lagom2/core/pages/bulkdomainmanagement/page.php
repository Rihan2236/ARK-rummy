<?php

return [
    'display_name' => 'Bulk Domain Management',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];