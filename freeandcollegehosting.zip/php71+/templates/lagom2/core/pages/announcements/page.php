<?php

return [
    'display_name' => 'Announcements',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'cms_type' => 'website',
    'listDisplay' => true,
    'variables'    => [

    ],
];