<?php

return [
    'display_name' => 'Domain Contact Info',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],  
];