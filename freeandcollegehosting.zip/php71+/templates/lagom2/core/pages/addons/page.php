<?php

return [
    'display_name' => 'Addons',
    'group'        => 'Order',
    'type' => 'order-process',
    'listDisplay' => true,
    'variables'    => [

    ],
];