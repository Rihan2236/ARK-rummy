<?php

return [
    'display_name' => 'Access Denied',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];