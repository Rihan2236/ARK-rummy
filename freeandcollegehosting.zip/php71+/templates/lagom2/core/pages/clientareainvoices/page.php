<?php

return [
    'display_name' => 'Invoices',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => true,
    'variables'    => [

    ],
];