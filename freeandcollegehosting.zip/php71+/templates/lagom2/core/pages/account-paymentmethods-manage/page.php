<?php

return [
    'display_name' => 'Account Payment Methods Manage',
    'group'        => 'Client Area',
    'type' => 'client-portal',
    'listDisplay' => false,
    'variables'    => [

    ],
];